# Japan in Dream Web App

🌸 A kawaii-themed Japan travel planner with:
- Mission checklist (with localStorage saving)
- Travel schedule planner
- Favorite places
- Dark mode toggle
- PWA-ready design (mobile-first)

👉 Built with HTML, CSS, and vanilla JavaScript.
